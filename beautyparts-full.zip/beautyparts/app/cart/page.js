'use client';

import Link from 'next/link';
import { useCart } from '@/context/CartContext';

export default function CartPage() {
  const { items, updateQuantity, removeItem, totalPrice, loaded } = useCart();

  if (!loaded) {
    return (
      <main>
        <h1>Кошик</h1>
        <p>Завантаження...</p>
      </main>
    );
  }

  if (items.length === 0) {
    return (
      <main>
        <h1>Кошик</h1>
        <p>Кошик порожній.</p>
        <Link href="/catalog">Перейти до каталогу</Link>
      </main>
    );
  }

  return (
    <main>
      <h1>Кошик</h1>

      <table>
        <thead>
          <tr>
            <th>Товар</th>
            <th>Ціна</th>
            <th>Кількість</th>
            <th>Сума</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.slug}>
              <td>
                <Link href={`/product/${item.slug}`}>{item.name}</Link>
              </td>
              <td>{item.price} грн</td>
              <td>
                <input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.slug, parseInt(e.target.value, 10) || 1)}
                  style={{ width: '60px' }}
                />
              </td>
              <td>{item.price * item.quantity} грн</td>
              <td>
                <button onClick={() => removeItem(item.slug)}>Видалити</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <p><strong>Разом до сплати: {totalPrice} грн</strong></p>

      <Link href="/checkout">
        <button>Оформити замовлення</button>
      </Link>
    </main>
  );
}
